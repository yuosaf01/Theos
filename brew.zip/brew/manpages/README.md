# Manual pages

This directory contains the generated Homebrew man pages from the `brew man` command. This command creates the output from `#:` comments in files, sections extracted from the repository's `README.md` and `brew.1.md.erb`.
