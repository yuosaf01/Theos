# Library

This directory contains all the code run by the official `brew` and `brew cask` commands in `Homebrew` and all formulae (package descriptions) in taps (repositories containing formulae) in `Taps` subdirectories.
