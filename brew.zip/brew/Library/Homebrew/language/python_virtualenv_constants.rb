# frozen_string_literal: true

PYTHON_VIRTUALENV_URL =
  "https://files.pythonhosted.org/packages/11/74" \
  "/2c151a13ef41ab9fb43b3c4ff9e788e0496ed7923b2078d42cab30622bdf" \
  "/virtualenv-16.7.4.tar.gz"
PYTHON_VIRTUALENV_SHA256 =
  "94a6898293d07f84a98add34c4df900f8ec64a570292279f6d91c781d37fd305"
