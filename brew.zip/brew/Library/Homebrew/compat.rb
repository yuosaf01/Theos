# frozen_string_literal: true

require "compat/cask/dsl/version"
require "compat/requirements/macos_requirement"
