# frozen_string_literal: true

require "extend/os/linux/tap" if OS.linux?
