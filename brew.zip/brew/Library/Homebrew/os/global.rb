# frozen_string_literal: true

require "os/linux/global" if OS.linux?
