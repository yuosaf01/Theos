# Completions
This directory contains subdirectories for `brew`'s tab completions for `bash`, `zsh`, and `fish`.
